Most of the textures here are from the Pixel Perfection V3.5 texture pack by
XSSheep.
Link: http://www.minecraftforum.net/forums/mapping-and-modding/resource-packs/1242533-pixel-perfection-freshly-updated-1-10
License: CC-BY-SA

Some of the grass/foliage textures were modified by pre-applying a green tint.

A smaller number of textures were filled in from the ProgrammerArt texture pack
by deathcap.
Link: https://github.com/deathcap/ProgrammerArt
License: CC-BY
